namespace CleanArchitecture.Domain.Vehiculos;

public record Vin(string Value);